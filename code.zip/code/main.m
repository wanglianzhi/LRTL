close all;
clear;
clc
%% add path
addpath(genpath('util'));
addpath(genpath('twist'));
dataname = {'h3k4me3_5k_10k'};
numdata = length(dataname);
resultdir = 'results/';
for cdata = 1:numdata
     %% read dataset
    disp(char(dataname(cdata)));
    datadir = 'data/';
    dataf = [datadir, cell2mat(dataname(cdata))];
    load(dataf);
    Y=label;view_num = length(X);size(X,2); class_num= max(Y);N=size(X{1},1);
    dv=cell(1,view_num);
    for v=1:view_num
             dv{v}=size(X{v},2);
     end
    for v = 1 :view_num
            for  j = 1:N
                 X{v}(j,:) = ( X{v}(j,:) - mean( X{v}(j,:) ) ) / std( X{v}(j,:) ) ;
            end
    end
        lammda=[10];
        pn=[15];
        run=1;
        X_fea=cell2mat(X)';
        X_fea=X_fea';
        d=size(X_fea,2);
        selecteddata=[];
      s=[100:50:300];
     for a=1:length(lammda)
        for b=1:length(pn)
            param.lammda=lammda(a);
            param.pn=pn(b);
            for i = 1 : run
                tic;
                [W]=method(X,view_num,class_num,N,dv,param);
                time_(i)=toc;
                w_con=[];
                for v=1:view_num
                    w_con=[w_con;W{v}];
                end
                [~,index] = sort(sum(w_con.*w_con,2),'descend');
                for j=1:length(s)
                    selecteddata=X_fea(:,index(1:s(j)));
                    [label_predict,center]=litekmeans(selecteddata,class_num);
                    result=ClusteringMeasure1(Y,label_predict);
                    AC(i,j)=result(1);
                    NM(i,j)=result(2);
                    purit(i,j)=result(3);
                    P(i, j) =result(4);
                    R(i, j) = result(5);
                    F(i, j) = result(6);
                    RI(i, j) =result(7);
                end
            end
        ACC_mean=mean(AC);
        ACC_mean_std=std(AC);
        NMI_mean=mean(NM);
        NMI_mean_std=std(NM);
        Purity_mean=mean(purit);
        Purity_mean_std=std(purit);
        P_mean=mean(P);
        P_mean_std=std(P);
        R_mean=mean(R);
        R_mean_std=std(R);
        F_mean=mean(F);
        F_mean_std=std(F);
        RI_mean=mean(RI);
        RI_mean_std=std(RI);
        time_(i+1)=sum(time_)/run;
        save([resultdir,char(dataname(cdata)),'_run_',num2str(run),'_lammda_',num2str(param.lammda),'_pn_',num2str(param.pn),'_result.mat'],'AC','ACC_mean','ACC_mean_std','NM','NMI_mean','NMI_mean_std','purit','Purity_mean','Purity_mean_std','P','P_mean','P_mean_std','R','R_mean','R_mean_std','F','F_mean','F_mean_std','RI','RI_mean','RI_mean_std','time_');
        clear AC ACC_mean ACC_mean_std NMI_mean NMI_mean_std Purity_mean Purity_mean_std P_mean P_mean_std R_mean R_mean_std F_mean F_mean_std RI_mean RI_mean_std time_ AC NM purit P R F RI;
     end
     end
end

