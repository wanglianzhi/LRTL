function [W]=method(X,view_num,class_num,N,dv,param)
%	X: Multi-view data matrix
%	L: The laplacian matrix.
%   F: the pseduo label matrix
%   S: the Similarity matrix
%   W: the feature selection matrix
    pn=param.pn;%the number of neighbors
    lammda=param.lammda; 
    rou = 1e-2; max_rou = 1e8;pho_rou =10;epsil=0.0001;eps=0.0001;
    thresh =1e-6;
    gamma=1e8;
    alpha = 1/view_num*ones(1,view_num);
    beta = 1/view_num*ones(1,view_num);
    %initialize
    for v=1:view_num
        temp_D{v}=diag(ones(dv{v},1));
    end
    for v=1:view_num
        S{v} = constructW_PKN(X{v}', pn);
        temp_Sv = (S{v}+S{v}')/2;
        Dv=diag(sum(temp_Sv));
        Lv=Dv-temp_Sv;
        L{v}=Lv;
        [F{v},~,~]=eig1(L{v},class_num,0);
        W{v}=zeros(dv{v},class_num);
    end
    for v=1:view_num 
        Q{v} = zeros(N,class_num);
        J{v} = zeros(N,class_num);
    end
    for v=1:view_num 
        Q{v}=Q{v}+rou*(F{v}-J{v});
    end
    iter=1;max_iter=100;
    while iter<max_iter
        fprintf('----processing iter %d--------\n', iter);
          %% update feature selection matrix Wv
         irr=1;max_irr=100;
         while irr<max_irr
             value_W1=0;value_W2=0;
             fprintf('----processing irr %d--------\n', irr);
             for v=1:view_num
                 value_W1 =value_W1+ beta(1,v)*norm(X{v}*W{v}-F{v},'fro')^2 + lammda*trace(W{v}'*temp_D{v}*W{v});
             end
             for v=1:view_num
                 temp_dd = zeros(dv{v},1);
                 for i = 1:dv{v}
                        temp_dd(i) = 1/(2*sqrt(W{v}(i,:)*W{v}(i,:)')+epsil);
                 end
                 temp_D{v}  = diag(temp_dd);
                 W{v}= (X{v}'*X{v} + (lammda/beta(1,v))*temp_D{v})\(X{v}'*F{v});
             end
             for v=1:view_num
                 value_W2 =value_W2+ beta(1,v)*norm(X{v}*W{v}-F{v},'fro')^2 + lammda*trace(W{v}'*temp_D{v}*W{v});
             end
             err_W=abs(value_W1-value_W2);
             if err_W<1e-4
                    break;
             end
             irr=irr+1;
         end
        
        %% update pseduo label matrix Fv
            for v=1:view_num
                G{v}=inv(X{v}'*X{v}+(lammda/beta(1,v))*temp_D{v});
                M{v}=alpha(1,v)*L{v}+beta(1,v)*(eye(N)-X{v}*G{v}*X{v}');
            end
            for v=1:view_num
                Ftop=(rou/2)*J{v}+gamma*F{v}+eps; 
                Fdown=M{v}*F{v}+(rou/2)*F{v}+(1/2)*Q{v}+gamma*F{v}*F{v}'*F{v}+eps;
                Frac=Ftop./Fdown;
                F{v}=F{v}.*Frac;
                F{v}=F{v}*diag(sqrt(1./(diag(F{v}'*F{v})+eps)));
            end
        %% update tensor J.
        Q_tensor = cat(3, Q{:,:});
        F_tensor = cat(3, F{:,:});
        Fv=F_tensor(:);
        Qv=Q_tensor(:);
        [Jv,objV]=wshrinkObj(Fv+1/rou*Qv,1/rou,[N,class_num,view_num],0,1);
        J_tensor=reshape(Jv,[N,class_num,view_num]);
        for v=1:view_num
             J{v}=J_tensor(:,:,v);
             Q{v}=Q{v}+rou*(F{v}-J{v});
        end 
        %% update parameters alpha��beta��rou
         for v=1:view_num
             alpha(1,v)=0.5/sqrt(trace(F{v}'*L{v}*F{v}));
             beta(1,v)=0.5/norm(X{v}*W{v}-F{v},'fro');
         end
         rou=min(rou*pho_rou,max_rou);
        %% check convergence��Match Error
         obj=0;
         for v=1:view_num 
             temp_obj=norm(F{v}-J{v},inf);
             obj = obj+temp_obj;
         end
         Objj(iter)=(1/view_num)*obj;
         if iter>3
             Objj_diff =abs( Objj(iter-1)-Objj(iter));
             if Objj_diff < thresh
                    break;
             end
         end
         iter=iter+1;
    end
end
